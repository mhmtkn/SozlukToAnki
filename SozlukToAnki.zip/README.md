# Sözlük To Anki

Android için Sesli Sözlük - AnkiDroid entegrasyon uygulaması. Sesli Sözlük'ten kopyaladığınız kelimeleri otomatik olarak AnkiDroid'e ekler.

## Özellikler

- Sesli Sözlük'ten kopyalanan kelimeleri otomatik yakalar
- AnkiDroid'e direkt kart ekler
- Arka planda çalışır
- Bildirim çubuğunda durum gösterir
- Otomatik başlatma seçeneği

## Gereksinimler

- Android 7.0 veya üstü
- AnkiDroid uygulaması
- Sesli Sözlük uygulaması

## Kurulum

1. APK dosyasını indirin
2. Android cihazınıza kurun
3. AnkiDroid'de "Sesli Sözlük" adında bir deste oluşturun
4. Uygulamaya gerekli izinleri verin

## Kullanım

1. Uygulamayı açın
2. "Servisi Başlat" butonuna basın
3. Sesli Sözlük'te bir kelimeye bakın
4. Kelime ve anlamını kopyalayın
5. Otomatik olarak AnkiDroid'e eklenecek
6. İşiniz bittiğinde "Servisi Durdur" butonuna basın

## Geliştirme

Bu projeyi geliştirmek için:

1. Repository'yi klonlayın
2. Android Studio'da açın
3. Gradle sync yapın
4. Geliştirmeye başlayın

## Katkıda Bulunma

1. Fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add some amazing feature'`)
4. Branch'inizi push edin (`git push origin feature/amazing-feature`)
5. Pull Request açın

## Lisans

MIT License altında dağıtılmaktadır. Daha fazla bilgi için `LICENSE` dosyasına bakın.

## İletişim

GitHub Issues üzerinden bildirimde bulunabilirsiniz.
