package com.example.sozluktoanki

import android.app.*
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import org.json.JSONObject

class ClipboardService : Service() {
    private lateinit var clipboardManager: ClipboardManager
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate() {
        super.onCreate()
        setupClipboardListener()
        startForeground()
    }

    private fun setupClipboardListener() {
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener {
            val clipData = clipboardManager.primaryClip
            if (clipData != null && clipData.itemCount > 0) {
                val text = clipData.getItemAt(0).text.toString()
                processClipboardText(text)
            }
        }
    }

    private fun processClipboardText(text: String) {
        // Sesli Sözlük formatını kontrol et
        val lines = text.split("\n")
        if (lines.size >= 2) {
            val word = lines[0].trim()
            val meaning = lines.subList(1, lines.size).joinToString("\n").trim()
            
            // AnkiDroid'e ekle
            addToAnki(word, meaning)
        }
    }

    private fun addToAnki(word: String, meaning: String) {
        serviceScope.launch {
            try {
                val intent = Intent("com.ichi2.anki.ADD_NOTE")
                intent.putExtra("modelName", "Basic")
                intent.putExtra("deckName", "Sesli Sözlük")
                
                val fields = JSONObject().apply {
                    put("Front", word)
                    put("Back", meaning)
                }
                intent.putExtra("fields", fields.toString())
                
                intent.putExtra("tags", arrayOf("sesli_sozluk", "otomatik"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                
                startActivity(intent)
                
                Toast.makeText(applicationContext, "Kart eklendi: $word", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(
                    applicationContext,
                    "Hata: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun startForeground() {
        val channelId = "SozlukToAnki"
        val channelName = "Sözlük To Anki Service"
        
        val channel = NotificationChannel(
            channelId,
            channelName,
            NotificationManager.IMPORTANCE_LOW
        )
        
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Sözlük To Anki")
            .setContentText("Kelime takibi aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        startForeground(1, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
