package com.example.sozluktoanki

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.sozluktoanki.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        checkOverlayPermission()
        setupUI()
    }

    private fun setupUI() {
        binding.buttonStart.setOnClickListener {
            startClipboardService()
        }

        binding.buttonStop.setOnClickListener {
            stopClipboardService()
        }

        binding.switchAutoStart.setOnCheckedChangeListener { _, isChecked ->
            // Save auto-start preference
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("auto_start", isChecked)
                .apply()
        }
    }

    private fun startClipboardService() {
        val serviceIntent = Intent(this, ClipboardService::class.java)
        startService(serviceIntent)
        Toast.makeText(this, "Servis başlatıldı", Toast.LENGTH_SHORT).show()
    }

    private fun stopClipboardService() {
        val serviceIntent = Intent(this, ClipboardService::class.java)
        stopService(serviceIntent)
        Toast.makeText(this, "Servis durduruldu", Toast.LENGTH_SHORT).show()
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Pencere izni gerekli!", Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val OVERLAY_PERMISSION_REQUEST_CODE = 1234
    }
}
